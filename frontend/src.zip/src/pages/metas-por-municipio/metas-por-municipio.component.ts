import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

type Jornada = 'GENERAL' | 'PICO' | 'VALLE';
type DiaTipo = 'TODOS' | 'HABIL' | 'NO_HABIL';

@Component({
  selector: 'app-metas-por-municipio',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './metas-por-municipio.component.html',
  styleUrls: ['./metas-por-municipio.component.scss'],
})
export class MetasPorMunicipioComponent {
  departamentos = ['ANTIOQUIA', 'CUNDINAMARCA', 'VALLE DEL CAUCA']; // luego lo sacamos de backend
  loading = false;

  filters: {
    departamento: string;
    fechaInicio?: string;
    fechaFin?: string;
    jornada: Jornada;
    dia: DiaTipo;
  } = {
    departamento: '',
    fechaInicio: '',
    fechaFin: '',
    jornada: 'GENERAL',
    dia: 'TODOS',
  };

  results?: {
    total: number;
    conDatos: number;
    sinDatos: number;
    items: { nombre: string; tieneDatos: boolean }[];
  };

  consultar() {
    this.loading = true;

    // ✅ MOCK mientras hacemos el endpoint real
    setTimeout(() => {
      const items = [
        { nombre: 'Municipio A', tieneDatos: true },
        { nombre: 'Municipio B', tieneDatos: false },
        { nombre: 'Municipio C', tieneDatos: true },
      ];

      const conDatos = items.filter(x => x.tieneDatos).length;
      this.results = {
        total: items.length,
        conDatos,
        sinDatos: items.length - conDatos,
        items,
      };

      this.loading = false;
    }, 500);
  }
}