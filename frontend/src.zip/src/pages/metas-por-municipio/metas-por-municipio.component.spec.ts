import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MetasPorMunicipioComponent } from './metas-por-municipio.component';

describe('MetasPorMunicipioComponent', () => {
  let component: MetasPorMunicipioComponent;
  let fixture: ComponentFixture<MetasPorMunicipioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MetasPorMunicipioComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MetasPorMunicipioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
