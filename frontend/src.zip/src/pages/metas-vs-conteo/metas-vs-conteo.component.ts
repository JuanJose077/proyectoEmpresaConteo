import { Component, OnInit } from '@angular/core';
import { CommonModule, JsonPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ReportService,
  DashboardResponse,
  DashboardRow,
} from '../../services/report.service';
import { CatalogService, MunicipioItem } from '../../services/catalog.service';
import { UiStateService } from '../../services/ui-state.service';

import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration, ChartData } from 'chart.js';


type Jornada = 'GENERAL' | 'PICO' | 'VALLE';
type DiaTipo = 'TODOS' | 'HABIL' | 'NO_HABIL';

@Component({
  selector: 'app-metas-vs-conteo',
  standalone: true,
  imports: [CommonModule, FormsModule, JsonPipe, BaseChartDirective],
  templateUrl: './metas-vs-conteo.component.html',
  styleUrls: ['./metas-vs-conteo.component.scss'],
})
export class MetasVsConteoComponent implements OnInit {
  data?: DashboardResponse;

  loading = false;
  loadingCatalogo = false;
  error?: string;

  departamentos: string[] = [];
  municipios: MunicipioItem[] = [];

  departamentoSeleccionado = '';
  municipioSeleccionadoId: number | null = null;

  showChart = false;
private readonly NO_APLICA: Record<string, string[]> = {
  'Uso del cinturón de seguridad':          ['MOTOCICLETA', 'BICICLETA', 'PEATÓN'],
  'Uso de sistemas de retención infantil':  ['MOTOCICLETA', 'BICICLETA', 'PEATÓN'],
  'Cumplimiento del límite de velocidad':   ['PEATÓN'],
  'Uso del sistema de luces':               ['PEATÓN'],
  'Uso del casco':                          ['AUTOMÓVIL', 'CAMIONETA', 'CAMPERO', 'TAXI', 'PEATÓN'],
  'Uso de prendas reflectivas':             ['AUTOMÓVIL', 'CAMIONETA', 'CAMPERO', 'TAXI', 'PEATÓN'],
  'Sobreocupación':                         ['PEATÓN'],
  'Maniobras de riesgo en vía':             ['PEATÓN'],
  'Comportamiento de peatones en cruces':   ['AUTOMÓVIL', 'CAMIONETA', 'CAMPERO', 'TAXI', 'MOTOCICLETA', 'BICICLETA'],
};

  aplica(label: string, vehiculo: string): boolean {
    const key = Object.keys(this.NO_APLICA).find((k) =>
      label.toLowerCase().includes(k.toLowerCase()),
    );
    if (!key) return true;
    return !this.NO_APLICA[key]
      .map((v) => v.toLowerCase())
      .includes(vehiculo.toLowerCase());
  }

  readonly vehicleColumns: string[] = [
    'Automóvil',
    'Camioneta',
    'Campero',
    'Taxi',
    'Motocicleta',
    'Bicicleta',
    'Peatón',
  ];

  filters: {
    fechaInicio: string;
    fechaFin: string;
    jornada: Jornada;
    dia: DiaTipo;
  } = {
    fechaInicio: '',
    fechaFin: '',
    jornada: 'GENERAL',
    dia: 'TODOS',
  };

  barChartType: 'bar' = 'bar';

  barChartData: ChartData<'bar' | 'line'> = {
    labels: [],
    datasets: [],
  };

  barChartOptions: ChartConfiguration<'bar' | 'line'>['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45,
        },
      },
      y: {
        beginAtZero: true,
        suggestedMax: 300,
        ticks: {
          callback: (value) => `${value}%`,
        },
      },
    },
    plugins: {
      legend: {
        display: true,
        position: 'bottom',
      },
      tooltip: {
        callbacks: {
          label: (context) => `${context.dataset.label}: ${context.parsed.y}%`,
        },
      },
    },
  };

  constructor(
    private reportService: ReportService,
    private catalogService: CatalogService,
    private uiState: UiStateService,
  ) {}

  ngOnInit(): void {
    const saved = this.uiState.getMetasVsConteoState();
    this.departamentoSeleccionado = saved.departamentoSeleccionado ?? '';
    this.municipioSeleccionadoId = saved.municipioSeleccionadoId ?? null;
    this.filters = {
      ...this.filters,
      ...(saved.filters ?? {}),
    };
    this.data = saved.data;

    this.cargarDepartamentos();

    if (this.data && this.showChart) {
      this.buildChart();
    }
  }

  private persistState() {
    this.uiState.setMetasVsConteoState({
      departamentoSeleccionado: this.departamentoSeleccionado,
      municipioSeleccionadoId: this.municipioSeleccionadoId,
      filters: { ...this.filters },
      data: this.data,
    });
  }

  cargarDepartamentos() {
    this.loadingCatalogo = true;
    this.catalogService.getDepartamentos().subscribe({
      next: (res) => {
        this.error = undefined;
        this.departamentos = res.items || [];
        this.loadingCatalogo = false;

        if (this.departamentoSeleccionado) {
          this.cargarMunicipios(this.departamentoSeleccionado);
        }
      },
      error: () => {
        this.error = 'No se pudo cargar la lista de departamentos';
        this.loadingCatalogo = false;
      },
    });
  }

  private cargarMunicipios(departamento: string) {
    this.loadingCatalogo = true;
    this.catalogService.getMunicipios(departamento).subscribe({
      next: (res) => {
        this.error = undefined;
        this.municipios = res.items || [];
        this.loadingCatalogo = false;
      },
      error: () => {
        this.error = 'No se pudo cargar la lista de municipios';
        this.loadingCatalogo = false;
      },
    });
  }

  getMunicipioNombre(): string {
    if (!this.municipioSeleccionadoId) return 'Todos';
    const found = this.municipios.find(
      (m) => m.id === this.municipioSeleccionadoId,
    );
    return found?.nombre ?? '—';
  }

  onDepartamentoChange() {
    this.error = undefined;
    this.municipioSeleccionadoId = null;
    this.municipios = [];
    this.data = undefined;

    if (this.showChart) {
      this.barChartData = { labels: [], datasets: [] };
    }

    this.persistState();

    if (!this.departamentoSeleccionado) return;

    this.cargarMunicipios(this.departamentoSeleccionado);
  }

  onMunicipioChange() {
    this.persistState();
  }

  onFilterChange() {
    this.persistState();
  }

  load() {
    this.error = undefined;

    if (!this.departamentoSeleccionado) {
      this.error = 'Selecciona un departamento.';
      return;
    }

    this.loading = true;

    const params: any = {
      departamento: this.departamentoSeleccionado,
      jornada: this.filters.jornada,
      dia: this.filters.dia,
    };

    if (this.municipioSeleccionadoId) {
      params.municipioId = this.municipioSeleccionadoId;
    }

    if (this.filters.fechaInicio?.trim()) {
      params.fechaInicio = this.filters.fechaInicio.trim();
    }

    if (this.filters.fechaFin?.trim()) {
      params.fechaFin = this.filters.fechaFin.trim();
    }

    this.reportService.getDashboard(params).subscribe({
      next: (res) => {
        this.data = res;
        this.loading = false;

        if (this.showChart) {
          this.buildChart();
        }

        this.persistState();
      },
      error: (err) => {
        this.error = err?.message || 'Error cargando dashboard';
        this.loading = false;
      },
    });
  }

  fmtPct(n: number | undefined | null): string {
    if (n === undefined || n === null) return '0.00';
    return Number(n).toFixed(2);
  }

  valueOf(
    map: Record<string, number> | undefined,
    key: string,
    fallback = 0,
  ): number {
    if (!map) return fallback;
    return map[key] ?? fallback;
  }

  statusOf(map: Record<string, boolean> | undefined, key: string): boolean {
    if (!map) return false;
    return !!map[key];
  }

  cumpleMeta(row: DashboardRow | any): boolean {
    return (row?.compliancePercent ?? 0) >= (row?.targetPercent ?? 0);
  }

  getAvanceClass(value: number): string {
    if (value >= 80) return 'avance-green';
    if (value >= 50) return 'avance-yellow';
    return 'avance-red';
  }

  toggleChart() {
    this.showChart = !this.showChart;

    if (this.showChart) {
      this.buildChart();
    }
  }

  buildChart() {
    if (!this.data?.table?.length) {
      this.barChartData = { labels: [], datasets: [] };
      return;
    }

    const labels = [
      '1. Cinturón',
      '2. Retención infantil',
      '3. Velocidad',
      '4. Luces',
      '5. Casco',
      '6. Reflectivas',
      '7. Sobreocupación',
      '8. Distractores',
      '9. Maniobras',
      '10. Peatones',
    ];

    const datasets = this.vehicleColumns.map((vehicle) => ({
      type: 'bar' as const,
      label: vehicle,
      data: this.data!.table.map((row) =>
        this.valueOf(row.avanceByVehicle, vehicle, 0),
      ),
    }));

    const targetLine = {
      type: 'line' as const,
      label: 'Meta 100%',
      data: this.data.table.map(() => 100),
      borderWidth: 2,
      pointRadius: 0,
      fill: false,
    };

    this.barChartData = {
      labels,
      datasets: [...datasets, targetLine],
    };
  }
}
